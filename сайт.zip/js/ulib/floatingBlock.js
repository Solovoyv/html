"use strict";!function(){var t=function(){return function(t){var o={init:function(){return function(){var o=this;o.container=t("#ul-content"),o.stickyTop=t(".ul-floating-sticky-top"),o.stickyBottom=t(".ul-floating-sticky-bottom"),o.fixedBlocks=t(".ul-floating-fixed"),o.fixedCloseButtons=t(".js-floating-button-close"),o.stickyTopCloseBtn=t(".js-sticky-top-close"),o.stickyBottomCloseBtn=t(".js-sticky-bottom-close"),o.initFixedCloseButtons(),o.initStickyTop(),o.initStickyBottom()}}(),initFixedCloseButtons:function(){return function(){var o=this;o.fixedCloseButtons.length&&o.fixedCloseButtons.on("click",function(){t(this).closest(".ul-floating-fixed").remove()})}}(),initStickyTop:function(){return function(){var o=this;if(o.stickyTop.length){var i=o.getTopBlockProps();o.elementToPlacehold=o.previous?o.previous:o.container,o.placeholdingProperty=o.previous?"margin-bottom":"margin-top",o.topPlaceholderEnabled=!1,t(window).on("scroll.stickyTopEvent",function(){var n=t(this).scrollTop();n>=i.top?(o.stickyTop.addClass("js-floating-fixed"),o.setTopPlaceholder(i.height)):(o.stickyTop.removeClass("js-floating-fixed"),o.removeTopPlaceholder(!1))}),o.stickyTopCloseBtn.length&&o.stickyTopCloseBtn.on("click",function(){o.deinitStickyTop()})}}}(),deinitStickyTop:function(){return function(){var o=this;o.stickyTop.removeClass("js-floating-fixed"),o.removeTopPlaceholder(),o.stickyTopCloseBtn.remove(),t(window).off(".stickyTopEvent"),delete o.stickyTopCloseBtn}}(),getTopBlockProps:function(){return function(){var t=this,o={},i=t.stickyTop.prev(":not(.ul-floating)"),n=t.stickyTop.prevAll(".ul-floating-sticky-bottom");return o.height=t.stickyTop.height(),o.previous=i.length?i:null,o.top=o.previous?o.previous.offset().top+o.previous.height():t.container.offset().top,n.length&&(o.top-=n.height()),o}}(),setTopPlaceholder:function(){return function(t){var o=this;o.topPlaceholderEnabled||(o.elementToPlacehold.css(o.placeholdingProperty,t+"px"),o.topPLaceholderEnabled=!0)}}(),removeTopPlaceholder:function(){return function(){var t=this;t.elementToPlacehold.css(t.placeholdingProperty,0),t.topPLaceholderEnabled=!1}}(),initStickyBottom:function(){return function(){var o=this;if(o.stickyBottom.length){var i=o.getBottomBlockProps();o.stickyBottom.addClass("js-floating-fixed").css("bottom",-i.height+"px"),o.container.css("margin-bottom",i.height),t(window).on("scroll.stickyBottomEvent",function(){var n=t(this).scrollTop()+t(window).height();n>=i.position?o.slideBottomBlock(n,i.position,i.height):o.stickyBottom.addClass("js-floating-fixed").css("bottom",-i.height+"px")}),o.stickyBottomCloseBtn.length&&o.stickyBottomCloseBtn.on("click",function(){o.deinitStickyBottom()})}}}(),deinitStickyBottom:function(){return function(){var o=this;o.stickyBottom.removeClass("js-floating-fixed"),o.container.css("margin-bottom","0"),o.stickyBottomCloseBtn.remove(),t(window).off(".stickyBottomEvent"),delete o.stickyBottomCloseBtn}}(),getBottomBlockProps:function(){return function(){var t=this,o={},i=t.stickyBottom.prev(":not(.ul-floating)");return o.height=t.stickyBottom.height(),o.previous=i.length?i:null,o.position=o.previous?o.previous.offset().top+o.previous.height():-o.height,o}}(),slideBottomBlock:function(){return function(t,o,i){var n=this,e=t-o-i;e>=0&&(e=0),n.stickyBottom.css("bottom",e)}}()};t(document).ready(function(){o.init(),t(window).trigger("scroll")})}}(),o=function(){return function(){window.require(["jquery"],function(o){t(o)})}}();"function"==typeof window.requireFullConfOnce?window.requireFullConfOnce(function(){o()}):o()}();
//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map

//# sourceMappingURL=floatingBlock.js.map
